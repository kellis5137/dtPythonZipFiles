from .wrapper import instrument


default_app_config = "autodynatrace.wrappers.django.apps.DynatraceConfig"
