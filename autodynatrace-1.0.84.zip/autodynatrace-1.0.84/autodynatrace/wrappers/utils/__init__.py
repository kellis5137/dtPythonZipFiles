from .imports import func_name
from .db import normalize_vendor
