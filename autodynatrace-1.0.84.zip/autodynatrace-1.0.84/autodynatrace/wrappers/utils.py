def func_name(view_func):
    return view_func.__name__


def normalize_vendor(name):
    return name
